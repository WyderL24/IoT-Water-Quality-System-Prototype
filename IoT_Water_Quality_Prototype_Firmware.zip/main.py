import network
import time
import machine
from umqtt.simple import MQTTClient
from machine import ADC, Pin
import onewire, ds18x20

# Wi-Fi credentials
WIFI_SSID = "your_wifi_ssid"
WIFI_PASSWORD = "your_wifi_password"

# MQTT config
MQTT_BROKER = "your_mqtt_broker_ip"
CLIENT_ID = "water_quality_monitor"

# Sensor pins
PH_PIN = 32
TDS_PIN = 33
TURBIDITY_PIN = 34
TEMP_PIN = 4

# Setup ADC sensors
ph_sensor = ADC(Pin(PH_PIN))
ph_sensor.atten(ADC.ATTN_11DB)

tds_sensor = ADC(Pin(TDS_PIN))
tds_sensor.atten(ADC.ATTN_11DB)

turbidity_sensor = ADC(Pin(TURBIDITY_PIN))
turbidity_sensor.atten(ADC.ATTN_11DB)

# Setup temperature sensor (DS18B20)
ds_pin = Pin(TEMP_PIN)
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
roms = ds_sensor.scan()

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(WIFI_SSID, WIFI_PASSWORD)
    while not wlan.isconnected():
        time.sleep(1)
    print('Connected to WiFi:', wlan.ifconfig())

def read_sensors():
    ds_sensor.convert_temp()
    time.sleep_ms(750)
    temp = ds_sensor.read_temp(roms[0])
    ph_val = ph_sensor.read()
    tds_val = tds_sensor.read()
    turb_val = turbidity_sensor.read()
    return {
        "temperature": temp,
        "ph": ph_val,
        "tds": tds_val,
        "turbidity": turb_val
    }

def publish_data(client, data):
    client.publish(b"water/temperature", str(data["temperature"]))
    client.publish(b"water/ph", str(data["ph"]))
    client.publish(b"water/tds", str(data["tds"]))
    client.publish(b"water/turbidity", str(data["turbidity"]))

def main():
    connect_wifi()
    client = MQTTClient(CLIENT_ID, MQTT_BROKER)
    client.connect()
    print("Connected to MQTT broker")
    while True:
        data = read_sensors()
        print("Publishing:", data)
        publish_data(client, data)
        time.sleep(15)

main()